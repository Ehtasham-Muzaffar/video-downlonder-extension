/**
 * Nova Video Downloader - Content Script
 * Scans page DOM for HTML5 video elements, extracts media information,
 * and renders modern floating download buttons.
 */

(() => {
  // Prevent duplicate execution
  if (window.__NOVA_DOWNLOADER_LOADED__) return;
  window.__NOVA_DOWNLOADER_LOADED__ = true;

  let showFloatingButton = true;
  let detectedUrls = new Set();
  let scanDebounceTimer = null;

  // Load user settings
  if (chrome.storage && chrome.storage.sync) {
    chrome.storage.sync.get(['showFloatingBtn'], (cfg) => {
      if (typeof cfg.showFloatingBtn === 'boolean') {
        showFloatingButton = cfg.showFloatingBtn;
      }
    });

    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'sync' && changes.showFloatingBtn) {
        showFloatingButton = changes.showFloatingBtn.newValue;
        document.querySelectorAll('.nova-floating-btn-container').forEach(el => {
          el.style.display = showFloatingButton ? 'flex' : 'none';
        });
      }
    });
  }

  /**
   * Show in-page toast notification
   */
  function showToast(message, isSuccess = true) {
    let toast = document.getElementById('nova-toast-root');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'nova-toast-root';
      toast.className = 'nova-toast-notification';
      document.body.appendChild(toast);
    }

    const iconSvg = isSuccess 
      ? `<svg class="nova-toast-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>`
      : `<svg class="nova-toast-icon" style="color: #ef4444" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><path stroke-linecap="round" d="M12 8v4m0 4h.01"/></svg>`;

    toast.innerHTML = `${iconSvg}<span>${message}</span>`;
    toast.classList.add('nova-toast-visible');

    setTimeout(() => {
      toast.classList.remove('nova-toast-visible');
    }, 3200);
  }

  /**
   * Determine platform name based on hostname
   */
  function getCurrentPlatform() {
    const host = window.location.hostname.toLowerCase();
    if (host.includes('facebook.com')) return 'Facebook';
    if (host.includes('instagram.com')) return 'Instagram';
    if (host.includes('youtube.com')) return 'YouTube';
    if (host.includes('tiktok.com')) return 'TikTok';
    if (host.includes('twitter.com') || host.includes('x.com')) return 'Twitter/X';
    if (host.includes('reddit.com')) return 'Reddit';
    if (host.includes('vimeo.com')) return 'Vimeo';
    return 'Web Video';
  }

  /**
   * Extract contextual title for the video based on platform
   */
  function extractContextualTitle(videoEl) {
    const platform = getCurrentPlatform();
    let title = '';

    if (platform === 'Instagram') {
      // Find closest article or dialog
      const article = videoEl.closest('article, div[role="dialog"]');
      if (article) {
        const author = article.querySelector('header a, span._ap3a, a.notranslate');
        const caption = article.querySelector('h1, span._a9zs, div._a9zs');
        const authorText = author ? author.innerText.trim() : '';
        const captionText = caption ? caption.innerText.slice(0, 40).trim() : '';
        if (authorText) title = `@${authorText}${captionText ? ' - ' + captionText : ''}`;
      }
    } else if (platform === 'Facebook') {
      const post = videoEl.closest('div[role="article"], div[data-ad-preview="message"], div.x1n2onr6');
      if (post) {
        const header = post.querySelector('h2, h3, h4, strong');
        const message = post.querySelector('div[dir="auto"], div[data-ad-preview="message"]');
        const headerText = header ? header.innerText.trim() : '';
        const messageText = message ? message.innerText.slice(0, 40).trim() : '';
        if (headerText) title = `${headerText}${messageText ? ' - ' + messageText : ''}`;
        else if (messageText) title = messageText;
      }
    } else if (platform === 'Twitter/X') {
      const tweet = videoEl.closest('article[data-testid="tweet"]');
      if (tweet) {
        const text = tweet.querySelector('div[data-testid="tweetText"]');
        if (text) title = text.innerText.slice(0, 50).trim();
      }
    }

    if (!title) {
      title = document.title ? document.title.replace(/\|.*$|- Facebook.*$|- Instagram.*$/i, '').trim() : 'Video';
    }

    return title || `${platform} Video`;
  }

  /**
   * Find poster / thumbnail for video
   */
  function extractThumbnail(videoEl) {
    if (videoEl.poster) return videoEl.poster;
    if (videoEl.getAttribute('poster')) return videoEl.getAttribute('poster');

    // Look for nearby thumbnail image in parent container
    const container = videoEl.closest('article, div[role="article"], div[role="dialog"]') || videoEl.parentElement;
    if (container) {
      const img = container.querySelector('img[src*="fbcdn.net"], img[src*="cdninstagram.com"], img[src*="image"]');
      if (img && img.src) return img.src;
    }
    return '';
  }

  /**
   * Format duration in mm:ss or hh:mm:ss
   */
  function formatDuration(sec) {
    if (!sec || isNaN(sec) || sec === Infinity) return '';
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = Math.floor(sec % 60);
    if (h > 0) {
      return `${h}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
    }
    return `${m}:${s.toString().padStart(2, '0')}`;
  }

  /**
   * Inject floating download button over video container
   */
  function attachFloatingButton(videoEl, videoUrl, quality, title, platform) {
    if (videoEl.dataset.novaAttached === 'true') return;
    videoEl.dataset.novaAttached = 'true';

    // Find suitable positioning parent
    let parent = videoEl.parentElement;
    if (!parent) return;

    // Ensure parent has position relative or wrapper
    const computed = window.getComputedStyle(parent);
    if (computed.position === 'static') {
      parent.classList.add('nova-video-wrapper');
    }

    const btnContainer = document.createElement('div');
    btnContainer.className = 'nova-floating-btn-container';
    btnContainer.style.display = showFloatingButton ? 'flex' : 'none';

    btnContainer.innerHTML = `
      <button type="button" class="nova-download-pill" title="Download this video with Nova Downloader">
        <svg viewBox="0 0 24 24">
          <path d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96zM17 13l-5 5-5-5h3V9h4v4h3z"/>
        </svg>
        <span>Download</span>
        <span class="nova-download-badge">${quality || 'HD'}</span>
      </button>
    `;

    const button = btnContainer.querySelector('.nova-download-pill');
    button.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();

      // Check URL: if blob and we don't have direct URL yet, use currentSrc or notify
      let targetUrl = videoUrl || videoEl.currentSrc || videoEl.src;
      
      if (!targetUrl || targetUrl.startsWith('blob:')) {
        // Trigger background scan to get underlying network stream
        chrome.runtime.sendMessage({
          action: 'FORCE_SCAN_TAB'
        });
        showToast('Scanning stream... Open Nova popup to download!', true);
        return;
      }

      showToast(`Starting download: ${platform} Video...`);

      const cleanFilename = `${platform}_${(title || 'Video').replace(/[/\\?%*:|"<>]/g, '_').slice(0, 40)}.mp4`;

      chrome.runtime.sendMessage({
        action: 'DOWNLOAD_MEDIA',
        url: targetUrl,
        filename: cleanFilename,
        platform
      }, (res) => {
        if (res && res.success) {
          showToast(`Download started!`);
        } else {
          showToast(`Download initiated via browser.`);
        }
      });
    });

    parent.appendChild(btnContainer);
  }

  /**
   * Scan DOM for HTML5 <video> elements
   */
  function scanVideos() {
    const videos = Array.from(document.querySelectorAll('video'));
    const detected = [];
    const platform = getCurrentPlatform();

    for (const v of videos) {
      // Find candidate URLs
      let src = v.currentSrc || v.src;

      // Check child <source> elements if src is empty
      if (!src) {
        const source = v.querySelector('source[src]');
        if (source) src = source.src;
      }

      const poster = extractThumbnail(v);
      const title = extractContextualTitle(v);
      const duration = v.duration && !isNaN(v.duration) ? Math.round(v.duration) : 0;
      const durationFormatted = formatDuration(duration);
      const width = v.videoWidth || 0;
      const height = v.videoHeight || 0;

      let quality = 'HD';
      if (height >= 1080) quality = '1080p FHD';
      else if (height >= 720) quality = '720p HD';
      else if (height >= 480) quality = '480p SD';

      // Attach floating in-page download button if on valid video
      if (src && !src.startsWith('chrome-extension://')) {
        attachFloatingButton(v, src, quality, title, platform);

        if (!detectedUrls.has(src) && !src.startsWith('blob:')) {
          detectedUrls.add(src);
          detected.push({
            url: src,
            title: `${platform} - ${title}`,
            poster,
            duration,
            durationFormatted,
            width,
            height,
            quality,
            platform,
            format: src.includes('.webm') ? 'WEBM' : 'MP4'
          });
        }
      }
    }

    // Send newly detected DOM videos to background
    if (detected.length > 0) {
      chrome.runtime.sendMessage({
        action: 'DOM_VIDEOS_FOUND',
        videos: detected
      });
    }

    return detected.length;
  }

  /**
   * Debounced video scanner
   */
  function scheduleScan() {
    if (scanDebounceTimer) clearTimeout(scanDebounceTimer);
    scanDebounceTimer = setTimeout(() => {
      scanVideos();
    }, 500);
  }

  // Initial scan
  scanVideos();

  // Watch for dynamic infinite scroll / post injection (Reels, Feed, etc.)
  const observer = new MutationObserver((mutations) => {
    let hasVideoChange = false;
    for (const m of mutations) {
      if (m.addedNodes.length > 0) {
        for (const n of m.addedNodes) {
          if (n.nodeType === Node.ELEMENT_NODE) {
            if (n.tagName === 'VIDEO' || (n.querySelector && n.querySelector('video'))) {
              hasVideoChange = true;
              break;
            }
          }
        }
      }
      if (hasVideoChange) break;
    }

    if (hasVideoChange) {
      scheduleScan();
    }
  });

  observer.observe(document.body || document.documentElement, {
    childList: true,
    subtree: true
  });

  // Listen for manual scan requests from popup
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === 'SCAN_VIDEOS_NOW') {
      const count = scanVideos();
      sendResponse({ count });
    }
  });
})();
