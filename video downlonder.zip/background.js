/**
 * Nova Video Downloader - Service Worker (Manifest V3)
 * Handles network sniffing, tab media registry, badge updates, and file downloads.
 */

// In-memory cache for fast access, backed by chrome.storage
const tabMedia = new Map();

// Helper to determine storage engine (session or local)
const getStorage = () => (chrome.storage && chrome.storage.session ? chrome.storage.session : chrome.storage.local);

// Video MIME types to detect
const VIDEO_MIME_TYPES = [
  'video/mp4',
  'video/webm',
  'video/ogg',
  'video/quicktime',
  'video/x-matroska',
  'video/x-flv',
  'video/3gpp',
  'application/x-mpegurl',
  'application/vnd.apple.mpegurl',
  'application/dash+xml'
];

// URL extensions to detect
const VIDEO_EXTENSIONS = ['.mp4', '.webm', '.mkv', '.mov', '.m4v', '.flv', '.m3u8', '.mpd'];

// Minimum video size in bytes (ignore tiny tracking pixels / audio pings < 64KB)
const MIN_VIDEO_BYTES = 64 * 1024;

/**
 * Format bytes into human readable string (e.g. 14.5 MB)
 */
function formatBytes(bytes) {
  if (!bytes || bytes <= 0) return 'Stream';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}

/**
 * Clean and normalize a video URL for deduplication
 */
function normalizeUrl(url) {
  try {
    const parsed = new URL(url);
    // Remove chunk range query params that cause duplicates on Facebook / CDNs
    parsed.searchParams.delete('bytestart');
    parsed.searchParams.delete('byteend');
    parsed.searchParams.delete('range');
    parsed.searchParams.delete('sq');
    parsed.hash = '';
    return parsed.toString();
  } catch (e) {
    return url.split('?')[0];
  }
}

/**
 * Detect platform from URL or initiator
 */
function detectPlatform(url, tabUrl = '') {
  const combined = (url + ' ' + tabUrl).toLowerCase();
  if (combined.includes('facebook.com') || combined.includes('fbcdn.net') || combined.includes('fb.watch')) {
    return 'Facebook';
  }
  if (combined.includes('instagram.com') || combined.includes('cdninstagram.com')) {
    return 'Instagram';
  }
  if (combined.includes('youtube.com') || combined.includes('youtu.be') || combined.includes('googlevideo.com')) {
    return 'YouTube';
  }
  if (combined.includes('tiktok.com') || combined.includes('tiktokcdn.com')) {
    return 'TikTok';
  }
  if (combined.includes('twitter.com') || combined.includes('x.com') || combined.includes('twimg.com')) {
    return 'Twitter/X';
  }
  if (combined.includes('reddit.com') || combined.includes('v.redd.it')) {
    return 'Reddit';
  }
  if (combined.includes('vimeo.com')) {
    return 'Vimeo';
  }
  return 'Web Video';
}

/**
 * Extract quality string (1080p, 720p, etc.) from dimensions or URL
 */
function estimateQuality(width, height, url = '') {
  if (height) {
    if (height >= 2160) return '4K UHD';
    if (height >= 1440) return '2K QHD';
    if (height >= 1080) return '1080p FHD';
    if (height >= 720) return '720p HD';
    if (height >= 480) return '480p SD';
    return `${height}p`;
  }
  if (width) {
    if (width >= 3840) return '4K UHD';
    if (width >= 1920) return '1080p FHD';
    if (width >= 1280) return '720p HD';
    return `${width}w`;
  }
  const u = url.toLowerCase();
  if (u.includes('1080p') || u.includes('1080')) return '1080p FHD';
  if (u.includes('720p') || u.includes('720')) return '720p HD';
  if (u.includes('480p') || u.includes('480')) return '480p SD';
  if (u.includes('360p')) return '360p';
  if (u.includes('.m3u8')) return 'HLS Stream';
  return 'HD';
}

/**
 * Sanitize filename for download
 */
function sanitizeFilename(title, platform = 'Video', ext = 'mp4') {
  let clean = (title || 'Video')
    .replace(/[/\\?%*:|"<>]/g, '_')
    .replace(/\s+/g, ' ')
    .trim();
  if (clean.length > 60) {
    clean = clean.substring(0, 60);
  }
  const dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  return `${platform}_${clean}_${dateStr}.${ext}`;
}

/**
 * Update extension action badge
 */
function updateBadge(tabId) {
  const list = tabMedia.get(tabId) || [];
  const count = list.length;
  chrome.action.setBadgeText({
    tabId,
    text: count > 0 ? String(count) : ''
  });
  chrome.action.setBadgeBackgroundColor({
    tabId,
    color: '#6366F1'
  });
}

/**
 * Save media state to persistent storage
 */
async function persistTabMedia(tabId) {
  try {
    const list = tabMedia.get(tabId) || [];
    const storage = getStorage();
    await storage.set({ [`tab_${tabId}`]: list });
  } catch (err) {
    // console.warn('Could not persist tab media:', err);
  }
}

/**
 * Load tab media from storage if not in memory
 */
async function loadTabMedia(tabId) {
  if (tabMedia.has(tabId)) {
    return tabMedia.get(tabId);
  }
  try {
    const storage = getStorage();
    const data = await storage.get(`tab_${tabId}`);
    const list = data[`tab_${tabId}`] || [];
    tabMedia.set(tabId, list);
    return list;
  } catch (err) {
    return [];
  }
}

/**
 * Register a newly detected video item
 */
function addOrUpdateMedia(tabId, mediaItem) {
  if (!tabId || tabId < 0) return;
  if (!mediaItem.url) return;

  // Filter out blob: URLs from network sniffer unless they have direct capture
  if (mediaItem.url.startsWith('blob:') && !mediaItem.isBlob) {
    return;
  }

  let list = tabMedia.get(tabId) || [];
  const norm = normalizeUrl(mediaItem.url);

  // Check if already in list
  const existingIndex = list.findIndex(item => normalizeUrl(item.url) === norm || item.id === mediaItem.id);

  if (existingIndex >= 0) {
    const existing = list[existingIndex];
    // Merge information (favor higher content length, better title, resolution)
    list[existingIndex] = {
      ...existing,
      ...mediaItem,
      size: Math.max(existing.size || 0, mediaItem.size || 0),
      sizeFormatted: formatBytes(Math.max(existing.size || 0, mediaItem.size || 0)),
      quality: mediaItem.quality || existing.quality,
      poster: mediaItem.poster || existing.poster,
      title: (mediaItem.title && mediaItem.title !== 'Video' && mediaItem.title !== 'Facebook Video' && mediaItem.title !== 'Instagram Video') 
             ? mediaItem.title 
             : existing.title
    };
  } else {
    // New item
    const newItem = {
      id: 'media_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6),
      url: mediaItem.url,
      cleanUrl: norm,
      title: mediaItem.title || 'Video',
      poster: mediaItem.poster || '',
      size: mediaItem.size || 0,
      sizeFormatted: formatBytes(mediaItem.size || 0),
      format: mediaItem.format || 'MP4',
      quality: mediaItem.quality || 'HD',
      duration: mediaItem.duration || 0,
      durationFormatted: mediaItem.durationFormatted || '',
      platform: mediaItem.platform || 'Web Video',
      detectedAt: Date.now()
    };
    list.unshift(newItem);
  }

  // Keep list bounded to 40 items per tab
  if (list.length > 40) {
    list = list.slice(0, 40);
  }

  tabMedia.set(tabId, list);
  persistTabMedia(tabId);
  updateBadge(tabId);
}

/**
 * Monitor network response headers for video streams
 */
chrome.webRequest.onHeadersReceived.addListener(
  (details) => {
    const { tabId, url, responseHeaders } = details;
    if (!tabId || tabId < 0) return;

    let contentType = '';
    let contentLength = 0;

    if (responseHeaders) {
      for (const h of responseHeaders) {
        const name = h.name.toLowerCase();
        if (name === 'content-type') {
          contentType = (h.value || '').toLowerCase();
        } else if (name === 'content-length') {
          contentLength = parseInt(h.value, 10) || 0;
        }
      }
    }

    const lowerUrl = url.toLowerCase();

    // Check if matching video content type or known video extension
    const isVideoMime = VIDEO_MIME_TYPES.some(m => contentType.includes(m));
    const isVideoExt = VIDEO_EXTENSIONS.some(ext => lowerUrl.includes(ext));
    const isFacebookVideo = (lowerUrl.includes('fbcdn.net') || lowerUrl.includes('facebook.com')) && 
                            (contentType.includes('video') || lowerUrl.includes('.mp4') || lowerUrl.includes('bytestart'));
    const isInstagramVideo = (lowerUrl.includes('cdninstagram.com') || lowerUrl.includes('fbcdn.net')) &&
                             (contentType.includes('video') || lowerUrl.includes('.mp4'));

    if (isVideoMime || isVideoExt || isFacebookVideo || isInstagramVideo) {
      // Ignore tiny chunks unless HLS playlist (.m3u8)
      if (!lowerUrl.includes('.m3u8') && contentLength > 0 && contentLength < MIN_VIDEO_BYTES) {
        return;
      }

      // Determine format
      let format = 'MP4';
      if (contentType.includes('webm') || lowerUrl.includes('.webm')) format = 'WEBM';
      else if (contentType.includes('mpegurl') || lowerUrl.includes('.m3u8')) format = 'M3U8';
      else if (contentType.includes('matroska') || lowerUrl.includes('.mkv')) format = 'MKV';
      else if (contentType.includes('ogg') || lowerUrl.includes('.ogg')) format = 'OGG';

      // Get tab info to extract tab title if available
      chrome.tabs.get(tabId, (tab) => {
        const tabTitle = (tab && tab.title) ? tab.title : 'Video';
        const platform = detectPlatform(url, tab ? tab.url : '');

        addOrUpdateMedia(tabId, {
          url,
          title: `${platform} - ${tabTitle}`,
          size: contentLength,
          format,
          quality: estimateQuality(0, 0, url),
          platform
        });
      });
    }
  },
  { urls: ['<all_urls>'] },
  ['responseHeaders']
);

/**
 * Handle tab navigation / refresh
 */
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'loading' && changeInfo.url) {
    // If the tab URL changed significantly, clear old tab media
    tabMedia.delete(tabId);
    persistTabMedia(tabId);
    updateBadge(tabId);
  }
});

/**
 * Handle tab close
 */
chrome.tabs.onRemoved.addListener((tabId) => {
  tabMedia.delete(tabId);
  try {
    getStorage().remove(`tab_${tabId}`);
  } catch (e) {}
});

/**
 * Listen for messages from popup and content scripts
 */
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const senderTabId = (sender && sender.tab && sender.tab.id) ? sender.tab.id : null;

  switch (message.action) {
    // Content script detected DOM video elements
    case 'DOM_VIDEOS_FOUND': {
      const tabId = senderTabId || message.tabId;
      if (tabId && Array.isArray(message.videos)) {
        for (const item of message.videos) {
          addOrUpdateMedia(tabId, {
            ...item,
            quality: estimateQuality(item.width, item.height, item.url)
          });
        }
      }
      sendResponse({ success: true });
      break;
    }

    // Popup requesting detected media for active tab
    case 'GET_TAB_MEDIA': {
      const tabId = message.tabId;
      loadTabMedia(tabId).then((list) => {
        sendResponse({ media: list || [] });
      });
      return true; // async response
    }

    // Clear media for tab
    case 'CLEAR_TAB_MEDIA': {
      const tabId = message.tabId;
      tabMedia.delete(tabId);
      persistTabMedia(tabId);
      updateBadge(tabId);
      sendResponse({ success: true });
      break;
    }

    // Download requested video file
    case 'DOWNLOAD_MEDIA': {
      const { url, filename, platform } = message;
      if (!url) {
        sendResponse({ success: false, error: 'Missing download URL' });
        return;
      }

      // Check if user set custom subfolder in options
      chrome.storage.sync.get(['downloadFolder', 'namingPattern'], (cfg) => {
        let finalFilename = filename || sanitizeFilename('Video', platform || 'Nova', 'mp4');
        const folder = (cfg.downloadFolder || '').trim();
        
        if (folder) {
          const cleanFolder = folder.replace(/[/\\]+$/, '');
          finalFilename = `${cleanFolder}/${finalFilename}`;
        }

        try {
          chrome.downloads.download(
            {
              url,
              filename: finalFilename,
              saveAs: false
            },
            (downloadId) => {
              if (chrome.runtime.lastError) {
                // If subfolder or filename fails, retry with basic filename in default folder
                chrome.downloads.download({
                  url,
                  saveAs: true
                }, (fallbackId) => {
                  if (chrome.runtime.lastError) {
                    sendResponse({ success: false, error: chrome.runtime.lastError.message });
                  } else {
                    sendResponse({ success: true, downloadId: fallbackId });
                  }
                });
              } else {
                sendResponse({ success: true, downloadId });
              }
            }
          );
        } catch (err) {
          sendResponse({ success: false, error: err.message });
        }
      });
      return true; // async response
    }

    // Force scan current tab DOM
    case 'FORCE_SCAN_TAB': {
      const tabId = message.tabId;
      if (tabId) {
        chrome.tabs.sendMessage(tabId, { action: 'SCAN_VIDEOS_NOW' }, (res) => {
          if (chrome.runtime.lastError) {
            sendResponse({ success: false, error: chrome.runtime.lastError.message });
          } else {
            sendResponse({ success: true, count: res ? res.count : 0 });
          }
        });
        return true;
      }
      break;
    }

    default:
      sendResponse({ status: 'unknown_action' });
  }
});
